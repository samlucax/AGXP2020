"""
S3 BUCKED CHECK OPEN LIST

Check if a bucket has opened file list.
"""

import sys
import requests
import xml.etree.ElementTree as ET

bucket_url = sys.argv[1]

response = requests.get(bucket_url)

xml = ET.fromstring(response.text)

for content in xml.iter():
    if 'Contents' in content.tag:
        print('Has opened files')
        exit(1)
