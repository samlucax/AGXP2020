import logging
import sys
import boto3
from botocore import UNSIGNED
from botocore.config import Config
from botocore.exceptions import ClientError


bucket_name = sys.argv[1]


s3_client = boto3.client(
    's3',
    config=Config(signature_version=UNSIGNED)
)

with open('blank_text_file.txt', 'rb') as file:
    try:
        object_key = 'hacked.txt'
        response = s3_client.upload_fileobj(file, bucket_name, object_key)
        print('File uploaded =/')
        object = s3_client.delete_object(Bucket=bucket_name, Key=object_key)
        exit(1)
    except ClientError as e:
        logging.error(e)
        exit(0)
