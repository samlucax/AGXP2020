## Requirements

To run this project you will need to:

* [Have docker installed and running](https://docs.docker.com/get-docker/)
* [Have docker composed installed](https://docs.docker.com/compose/install/)
* [Have node 12 or higher configured](https://nodejs.org/en/)

## Setup

Open the terminal and run these scripts:
* `npm install`
* `docker-compose up -d`

It could take some minutes to complete.

## Open Cypress Tests

In the terminal, run:
* `npm run open`


## Juice Shop

The docker compose file includes a running instance of `Juice Shop` (an application with vulnerabilies).

To access, just open `http://localhost:3000` in your browser.

**Hey!**

Do not forgot that `localhost` does not exists inside a container.

If an application is running in your host and you want to access inside a contaier, you should replace `localhost` for `host.docker.internal`:

Ex: `http://localhost:3000` turns into `http://host.docker.internal:3000`.
