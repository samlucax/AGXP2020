Cypress.Commands.add('nmapScanCommonPorts', (host) => {
	const command = `docker exec -i nmap nmap -F ${host} | grep "open"`
	return cy.exec(
		command,
		{failOnNonZeroExit: false}
	).then(nmapRawResponse => {
		if (nmapRawResponse.code > 0 || !nmapRawResponse.stdout) {
			return []
		}

		const lines = nmapRawResponse.stdout.split('\n')
		const ports = lines.map(line => {
			return +line.split('/')[0]
		})

		return ports
	})
})
