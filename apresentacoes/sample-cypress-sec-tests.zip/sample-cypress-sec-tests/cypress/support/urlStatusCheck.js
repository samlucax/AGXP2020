Cypress.Commands.add('urlStatusCheck', (url) => {
	const command = `curl --head ${url} | grep "200 OK"`
	return cy.exec(
		command,
		{
			failOnNonZeroExit: false
		}
	).then(result => {
		return result.code == 0 && !!result.stdout
	})
})
