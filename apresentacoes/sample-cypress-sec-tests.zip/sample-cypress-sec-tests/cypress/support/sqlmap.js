Cypress.Commands.add('sqlmapIsInjectable', (url) => {
	const command = `docker exec -i sqlmap sqlmap -u "${url}" --answers="follow=Y" --batch --banner --level=2`
	return cy.exec(
		command,
		{failOnNonZeroExit: false}
	).then(sqlmapResult => {
		const bannerFound = sqlmapResult.stdout.indexOf("banner: '") >= 0

		return {
			injectable: bannerFound,
			cmdOutput: sqlmapResult
		}
	})
})
