Cypress.Commands.add('xssUrlQueryExists', (url) => {
	const injection = '<i id="xss-test">HACKED</i>'
	const urlWithInjection = url.replace('*XSS*', encodeURIComponent(injection))

	return cy.visit(urlWithInjection, {timeout: 10000})
			.get('#xss-test')
				.then(el => {
					return !!el && el.length && el[0].innerText === 'HACKED'
				})
})

