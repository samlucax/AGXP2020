Cypress.Commands.add('s3IsBrowseable', (bucketUrl) => {
	const command = `docker exec -i python-scripts python s3_bucket_check_open_list.py ${bucketUrl}`
	return cy.exec(
		command,
		{
			failOnNonZeroExit: false
		}
	).then(result => {
		return result.code > 0
	})
})

Cypress.Commands.add('s3HasPublicWrite', (bucketName) => {
	const command = `docker exec -i python-scripts python s3_bucket_check_write_protection.py ${bucketName}`
	return cy.exec(
		command,
		{
			failOnNonZeroExit: false
		}
	).then(result => {
		return result.code > 0
	})
})
