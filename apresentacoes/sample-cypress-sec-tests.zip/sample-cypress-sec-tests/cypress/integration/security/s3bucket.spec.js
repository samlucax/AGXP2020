/// <reference types="cypress" />

context('S3 Bucket', () => {
	describe('Validating exposition', () => {
		it('Should not be browseable', () => {
			const BUCKET_URL = 'http://spainintheusa.org.s3.amazonaws.com'

			cy.s3IsBrowseable(BUCKET_URL)
				.then(isBrowseable => {
					expect(isBrowseable).to.be.false
				})
		})

		it('Should not be writeable', () => {
			const BUCKET_NAME = 'nhdata'
			cy.s3HasPublicWrite(BUCKET_NAME)
				.then(isWriteable => {
					expect(isWriteable).to.be.false
				})
		})
	})
})
