/// <reference types="cypress" />

context('SQLMAP', () => {
	describe('Validating product search api', () => {
		// injectable
		const URL = 'http://host.docker.internal:3000/rest/products/search?q=test'

		// non injectable
		// const URL = 'http://host.docker.internal:3000/rest/admin/application-configuration?q=1'

		it('Should not have injection', () => {
			cy.sqlmapIsInjectable(URL)
				.then(result => {
					expect(result.injectable).to.be.false
				})
		})
	})
})
