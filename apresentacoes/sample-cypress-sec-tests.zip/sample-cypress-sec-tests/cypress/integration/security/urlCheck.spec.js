/// <reference types="cypress" />

context('URL Check', () => {
	describe('Validating directories', () => {
		const url = 'http://localhost:3000/ftp'

		it('Only valid paths should be visible', () => {
			cy.urlStatusCheck(url)
				.then(status => {
					expect(status).to.be.false
				})
		})
	})
})
