/// <reference types="cypress" />

context('XSS', () => {
	describe('Validating routes', () => {
		const url = 'http://localhost:3000/#/search?q=*XSS*'

		it('Should not have xss injection', () => {
			cy.xssUrlQueryExists(url)
				.then(status => {
					expect(status).to.be.false
				})
		})
	})
})

