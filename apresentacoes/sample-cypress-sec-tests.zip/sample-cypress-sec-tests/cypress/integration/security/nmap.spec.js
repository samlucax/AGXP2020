/// <reference types="cypress" />

context('NMAP', () => {
	describe('Validating ports in cwi.com.br', () => {
		const HOST = 'cwi.com.br'

		it('Only 80 and 443 ports should be open', () => {
			const expectedOpenedPorts = [80, 443]
			cy.nmapScanCommonPorts(HOST)
				.then(openedPorts => {
					expect(openedPorts).to.deep.equal(expectedOpenedPorts)
				})
		})
	})
})
